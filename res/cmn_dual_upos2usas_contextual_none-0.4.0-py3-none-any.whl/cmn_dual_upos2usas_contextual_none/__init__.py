from typing import Union, Iterable, Dict, Any
from pathlib import Path
from spacy.util import get_model_meta, SimpleFrozenList, SimpleFrozenDict, load_model_from_path
from thinc.api import Config

__version__ = get_model_meta(Path(__file__).parent)['version']

def load_model_from_init_py(
    init_file: Union[Path, str],
    *,
    vocab: Union["Vocab", bool] = True,
    disable: Iterable[str] = SimpleFrozenList(),
    enable: Iterable[str] = SimpleFrozenList(),
    exclude: Iterable[str] = SimpleFrozenList(),
    config: Union[Dict[str, Any], Config] = SimpleFrozenDict(),
) -> "Language":
    '''Helper function to use in the `load()` method of a model package's
    __init__.py.
    vocab (Vocab / True): Optional vocab to pass in on initialization. If True,
        a new Vocab object will be created.
    disable (Iterable[str]): Names of pipeline components to disable. Disabled
        pipes will be loaded but they won't be run unless you explicitly
        enable them by calling nlp.enable_pipe.
    enable (Iterable[str]): Names of pipeline components to enable. All other
        pipes will be disabled.
    exclude (Iterable[str]): Names of pipeline components to exclude. Excluded
        components won't be loaded.
    config (Dict[str, Any] / Config): Config overrides as nested dict or dict
        keyed by section values in dot notation.
    RETURNS (Language): The loaded nlp object.
    '''
    model_path = Path(init_file).parent
    meta = get_model_meta(model_path)
    data_dir = meta['name'] + '-' + meta['version']
    data_path = model_path / data_dir
    if not model_path.exists():
        raise IOError(Errors.E052.format(path=data_path))
    return load_model_from_path(
        data_path,
        vocab=vocab,
        meta=meta,
        enable=enable,
        disable=disable,
        exclude=exclude,
        config=config,
    )


def load(**overrides):
    return load_model_from_init_py(__file__, **overrides)
