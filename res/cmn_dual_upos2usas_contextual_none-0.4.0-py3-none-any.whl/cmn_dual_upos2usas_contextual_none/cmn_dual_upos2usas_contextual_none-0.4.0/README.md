| Feature | Description |
| --- | --- |
| **Name** | `cmn_dual_upos2usas_contextual_none` |
| **Version** | `0.4.0` |
| **spaCy** | `>=3.0,<4.0` |
| **Default Pipeline** | `pymusas_rule_based_tagger` |
| **Components** | `pymusas_rule_based_tagger` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | `CC BY-NC-SA 4.0` |
| **Author** | [UCREL Research Centre](https://ucrel.github.io/pymusas/) |
| **Model size** | n/a |